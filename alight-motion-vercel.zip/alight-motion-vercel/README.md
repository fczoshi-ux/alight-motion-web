# Alight Motion Web — Vercel

Versi Vercel dari website Alight Motion yang sebelumnya berjalan di Node/Express.

## Yang sudah dipindahkan
- Landing page mobile-friendly
- Produk Generator Rp3.000 dan Buyer Rp5.000
- Testimoni
- Checkout/order API
- Cek status order
- Admin API untuk melihat dan mengubah status order
- Secret admin tetap di environment variable

## Penting: storage
Vercel Functions tidak cocok untuk menyimpan perubahan ke file JSON lokal secara permanen. Karena itu order disimpan di **Vercel Blob Private**. Vercel sendiri mendokumentasikan bahwa filesystem runtime serverless bersifat read-only untuk penyimpanan aplikasi, dan private Blob cocok untuk data yang harus tetap server-side.

## Deploy
1. Upload/import project ini ke Vercel.
2. Di project Vercel buka **Storage → Create Database → Blob**.
3. Pilih **Private** lalu hubungkan ke project. Vercel akan menyediakan kredensial Blob untuk Function.
4. Buka **Settings → Environment Variables**.
5. Tambahkan:
   - `ADMIN_KEY` = kunci admin rahasia yang panjang.
6. Redeploy project.

Setelah itu website bisa dibuka dari domain `*.vercel.app` milik project.

## Catatan
- Payment gateway belum terpasang. Checkout saat ini hanya membuat order.
- Testimoni di data awal masih placeholder; ganti dengan testimoni asli.
- Jangan pernah memasukkan `ADMIN_KEY` ke `script.js` atau HTML.
