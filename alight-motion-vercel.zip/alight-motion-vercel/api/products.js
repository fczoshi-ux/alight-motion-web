const { loadStore } = require('../lib/store');

module.exports = async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method tidak diizinkan.' });
  try {
    const data = await loadStore();
    return res.status(200).json(data.products || []);
  } catch (e) {
    return res.status(500).json({ error: 'Gagal memuat produk.' });
  }
};
