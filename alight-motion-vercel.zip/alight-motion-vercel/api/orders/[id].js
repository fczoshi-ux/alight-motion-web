const { loadStore } = require('../../lib/store');

module.exports = async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method tidak diizinkan.' });
  try {
    const data = await loadStore();
    const order = (data.orders || []).find(x => x.id === req.query.id);
    if (!order) return res.status(404).json({ error: 'Pesanan tidak ditemukan.' });
    return res.status(200).json({
      id: order.id,
      product: order.product,
      amount: order.amount,
      status: order.status,
      createdAt: order.createdAt
    });
  } catch (e) {
    return res.status(500).json({ error: 'Gagal mengambil pesanan.' });
  }
};
