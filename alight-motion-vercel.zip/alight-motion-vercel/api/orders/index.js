const crypto = require('crypto');
const { loadStore, saveStore } = require('../../lib/store');

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method tidak diizinkan.' });
  try {
    const { productId, buyerName, buyerContact } = req.body || {};
    const data = await loadStore();
    const product = (data.products || []).find(x => x.id === Number(productId));
    if (!product) return res.status(400).json({ error: 'Produk tidak ditemukan.' });

    if (typeof buyerName !== 'string' || buyerName.trim().length < 2 || buyerName.trim().length > 80) {
      return res.status(400).json({ error: 'Nama tidak valid.' });
    }
    if (typeof buyerContact !== 'string' || buyerContact.trim().length < 5 || buyerContact.trim().length > 120) {
      return res.status(400).json({ error: 'Kontak tidak valid.' });
    }

    const order = {
      id: 'AM-' + crypto.randomBytes(4).toString('hex').toUpperCase(),
      productId: product.id,
      product: product.name,
      amount: product.price,
      buyerName: buyerName.trim(),
      buyerContact: buyerContact.trim(),
      status: 'MENUNGGU PEMBAYARAN',
      createdAt: new Date().toISOString()
    };

    data.orders = Array.isArray(data.orders) ? data.orders : [];
    data.orders.push(order);
    await saveStore(data);
    return res.status(201).json({ success: true, order });
  } catch (e) {
    return res.status(500).json({ error: e.message || 'Gagal membuat pesanan.' });
  }
};
