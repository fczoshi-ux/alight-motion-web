const { loadStore, saveStore } = require('../../../lib/store');
const { adminOnly } = require('../../../lib/http');

module.exports = async function handler(req, res) {
  if (req.method !== 'PATCH') return res.status(405).json({ error: 'Method tidak diizinkan.' });
  if (!adminOnly(req, res)) return;

  const allowed = ['MENUNGGU PEMBAYARAN', 'DIBAYAR', 'DIPROSES', 'SELESAI', 'DIBATALKAN'];
  if (!allowed.includes(req.body?.status)) return res.status(400).json({ error: 'Status tidak valid.' });

  try {
    const data = await loadStore();
    const order = (data.orders || []).find(x => x.id === req.query.id);
    if (!order) return res.status(404).json({ error: 'Order tidak ditemukan.' });
    order.status = req.body.status;
    await saveStore(data);
    return res.status(200).json({ success: true, order });
  } catch (e) {
    return res.status(500).json({ error: e.message || 'Gagal memperbarui order.' });
  }
};
