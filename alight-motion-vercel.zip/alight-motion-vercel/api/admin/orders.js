const { loadStore } = require('../../lib/store');
const { adminOnly } = require('../../lib/http');

module.exports = async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method tidak diizinkan.' });
  if (!adminOnly(req, res)) return;
  try {
    const data = await loadStore();
    return res.status(200).json(data.orders || []);
  } catch (e) {
    return res.status(500).json({ error: 'Gagal memuat pesanan.' });
  }
};
